﻿using ClientServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Server
{
    public class Server
    {
        // Объект, принимающий TCP-клиентов
        private static TcpListener tcpListener = null;
        private const int port = 9999;
        public List<Client> clients = new List<Client>();
        // Метод ожидания соединия клиентов с сервером
        protected internal void Listen()
        {
            Console.WriteLine("Ожидание подключения клиентов");

            try
            {
                //определяем кол-во доступных потоков для выполнения задач(ThreadPool)
                int MaxThreadsCount = Environment.ProcessorCount * 4;
                ThreadPool.SetMaxThreads(MaxThreadsCount, MaxThreadsCount);
                ThreadPool.SetMinThreads(2, 2);
                tcpListener = new TcpListener(IPAddress.Any, port);
                tcpListener.Start();

                while (true)
                {
                    //запускаем прослушивание и ожидаем подключения
                    TcpClient tcpClient = tcpListener.AcceptTcpClient();
                    //создается объект Client, передаваемый ему tcpClient и ссылку на текущий сервер
                    Client ClientObject = new Client(tcpClient, this);
                    //Создание объекта Client выполняется в отдельном потоке, используя ThreadPool
                    ThreadPool.QueueUserWorkItem(ClientObject.Receive);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                tcpListener.Stop();
            }
        }
    }


    public class Client : ProcessTask
    {
        protected internal TcpClient client;
        protected internal NetworkStream stream;//поток для записи\чтения данных
        protected internal Server server;
        protected internal string name;

        public Client(TcpClient _tcpClient, Server _server)
        {
            this.client = _tcpClient;
            this.stream = client.GetStream();
            this.server = _server;
        }


        public void Send(Protocol.Tasks task, string buffer = null)
        {
            try
            {
                //задание (enum `Protocol.Tasks`) преобразуется в массив байтов
                //и записывается в поток с использованием метода `Write` объекта `stream` клиента
                byte[] test = BitConverter.GetBytes((int)task);
                stream.Write(BitConverter.GetBytes((int)task), 0, Protocol.task_size);

                if (buffer != null)
                {
                    //размер данных задания (`msg_size`) вычисляется с использованием метода `GetByteCount`
                    //класса `Encoding.Unicode` и записывается в поток.
                    int msg_size = Encoding.Unicode.GetByteCount(buffer);
                    byte[] msg_size_bytes = BitConverter.GetBytes(msg_size);
                    //данные задания (`msg`) преобразуются в массив байтов с помощью метода `GetBytes` класса `Encoding.Unicode`
                    //и записываются в поток.
                    byte[] msg = Encoding.Unicode.GetBytes(buffer);

                    stream.Write(msg_size_bytes, 0, Protocol.size_size);
                    stream.Write(msg, 0, msg_size);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public void Receive(object _object)
        {
            try
            {
                byte[] task_bytes = new byte[Protocol.task_size];

                while (true)
                {
                    //чтение данных из потока клиента в массив `task_bytes` с помощью метода `Read` объекта `stream`
                    stream.Read(task_bytes, 0, Protocol.task_size);
                    //с помощью метода `ToInt32` класса `BitConverter`, данные в массиве `task_bytes` преобразуются
                    //в число типа `int` и сохраняются в переменную `Command`
                    int Command = BitConverter.ToInt32(task_bytes, 0);

                    switch (Command)
                    {
                        case (int)Protocol.Tasks.Connect:
                            Connect();
                            break;

                        case (int)Protocol.Tasks.Disconnect:
                            Disconnect();
                            return;

                        case (int)Protocol.Tasks.Message:
                            Message();
                            break;
                    }
                }
            }
            catch
            {
                Disconnect();
            }
        }


        public void Connect()
        {
            byte[] msg_size_bytes = new byte[Protocol.size_size];
            stream.Read(msg_size_bytes, 0, Protocol.size_size);

            int msg_size = BitConverter.ToInt32(msg_size_bytes, 0);
            byte[] msg_bytes = new byte[msg_size];
            stream.Read(msg_bytes, 0, msg_size);

            string message = Encoding.Unicode.GetString(msg_bytes, 0, msg_size);

            // Проверка наличия имени
            if (string.IsNullOrWhiteSpace(message))
            {
                Send(Protocol.Tasks.Disconnect, "Error: Empty name. Please enter a valid name.");
                Disconnect();
                return;
            }

            // Проверка наличия дубликата имени
            if (server.clients.Any(c => c.name == message))
            {
                Send(Protocol.Tasks.Disconnect, "Error: Duplicate name. Please choose a different name.");
                Disconnect();
                return;
            }

            name = message;
            server.clients.Add(this);

            string out_msg = null;
            for (int i = 0; i < server.clients.Count; i++)
            {
                out_msg += server.clients[i].name + "!";
            }

            for (int i = 0; i < server.clients.Count; i++)
            {
                server.clients[i].Send(Protocol.Tasks.Connect, out_msg);
                server.clients[i].Send(Protocol.Tasks.Message, name + " подключился" + "\r\n");
            }
            Console.WriteLine(name + " подключился");
        }




        public void Disconnect()
        {
            stream.Close();//закрываем потоки
            client.Close();
            server.clients.Remove(this);//удаляем из списка
            for (int i = 0; i < server.clients.Count; i++)
            {
                server.clients[i].Send(Protocol.Tasks.Disconnect, name);
                server.clients[i].Send(Protocol.Tasks.Message, name + " отключился" + "\r\n");
                Console.WriteLine(name + " отключился");
            }
        }


        public void Message()
        {
            byte[] msg_size_bytes = new byte[Protocol.size_size];
            stream.Read(msg_size_bytes, 0, Protocol.size_size);

            int msg_size = BitConverter.ToInt32(msg_size_bytes, 0);
            byte[] msg_bytes = new byte[msg_size];
            stream.Read(msg_bytes, 0, msg_size);

            string message = Encoding.Unicode.GetString(msg_bytes, 0, msg_size);

            // Проверяем, является ли сообщение личным сообщением
            if (message.StartsWith("/лично"))
            {
                // Извлекаем имя целевого клиента
                string[] parts = message.Split(' ');
                if (parts.Length >= 3)
                {
                    string targetClientName = parts[1];
                    string privateMessage = string.Join(" ", parts, 2, parts.Length - 2);

                    // Находим целевого клиента в списке клиентов сервера
                    Client targetClient = server.clients.FirstOrDefault(c => c.name == targetClientName);

                    // Отправляем личное сообщение только целевому клиенту
                    if (targetClient != null)
                    {
                        // Добавляем информацию о том, что отправитель видит свое сообщение
                        Send(Protocol.Tasks.Message, $"{name} (личное, для {targetClientName}): {privateMessage}\r\n");
                        targetClient.Send(Protocol.Tasks.Message, $"{name} (личное): {privateMessage}\r\n");
                    }
                    else
                    {
                        // Информируем отправителя о том, что целевой клиент не найден
                        Send(Protocol.Tasks.Message, $"Ошибка: Пользователь '{targetClientName}' не найден\r\n");
                    }
                }
            }
            else
            {
                // Рассылаем обычные сообщения всем клиентам
                for (int i = 0; i < server.clients.Count; i++)
                {
                    server.clients[i].Send(Protocol.Tasks.Message, $"{name}: {message}\r\n");
                    Console.WriteLine($"Сообщение для {server.clients[i].name}: {message}");
                }
            }
        }


    }
}

