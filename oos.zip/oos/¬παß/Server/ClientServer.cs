﻿using System;

namespace ClientServer
{
    public class Protocol
    {
        public const int task_size = 4;
        public const int size_size = 4;

        public enum Tasks : int
        {
            None,
            Connect,
            Disconnect,
            Message
        }
    }
    public interface ProcessTask
    {
        void Connect();
        void Disconnect();
        void Message();
        void Send(Protocol.Tasks task, string buffer = null);
        void Receive(object _object);
    }
}
