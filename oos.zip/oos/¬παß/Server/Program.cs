﻿using System;
using System.Threading;

namespace Server
{
    class Program
    {
        static Server server;
        static Thread listen;

        static void Main(string[] args)
        {
            try
            {
                server = new Server();
                listen = new Thread(new ThreadStart(server.Listen));
                // метод `Start()` вызывается на переменной `listen`, чтобы запустить нить и начать прослушивание подключений на сервере.
                listen.Start();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}

