﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClientServer;

namespace Client
{
    public partial class Form1 : Form, ProcessTask
    {
        private NetworkStream stream;
        private Thread Receiver;
        private TcpClient tcpClient;
        private bool connection = false;

        public Form1()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            InitializeComponent();

        }
        public void Send(Protocol.Tasks task, string buffer = null)
        {
            try
            {
                if (connection == true)
                {
                    stream.Write(BitConverter.GetBytes((int)task), 0, Protocol.task_size);

                    if (buffer != null)
                    {
                        int msg_size = Encoding.Unicode.GetByteCount(buffer);
                        byte[] msg_size_bytes = BitConverter.GetBytes(msg_size);
                        stream.Write(msg_size_bytes, 0, Protocol.size_size);

                        byte[] msg = Encoding.Unicode.GetBytes(buffer);
                        stream.Write(msg, 0, msg_size);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "SendMessage()", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
        }
        public void Receive(object _object)
        {
            try
            {

                byte[] task_bytes = new byte[Protocol.task_size];
                while (true)
                {
                    stream.Read(task_bytes, 0, Protocol.task_size);
                    int task = BitConverter.ToInt32(task_bytes, 0);

                    switch (task)
                    {
                        case (int)Protocol.Tasks.Connect:
                            Connect();
                            break;

                        case (int)Protocol.Tasks.Disconnect:
                            Disconnect();
                            break;

                        case (int)Protocol.Tasks.Message:
                            Message();
                            break;
                    }
                }
            }
            catch (SocketException ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void chat_richTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void connect_button_Click(object sender, EventArgs e)
        {
            if (username_textBox.Text != "")
            {
                try
                {
                    if (ip_textBox.Text != "" && port_textBox.Text != "")
                    {
                        tcpClient = new TcpClient(ip_textBox.Text, Convert.ToInt32(port_textBox.Text));
                        stream = tcpClient.GetStream();
                        connection = true;

                        Receiver = new Thread(Receive);
                        Receiver.IsBackground = true;
                        Receiver.Start();

                        disconnect_button.Visible = true;
                        connect_button.Visible = false;

                        Send(Protocol.Tasks.Connect, username_textBox.Text);
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Введите ваше имя", "Ошибка", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }

        }

        private void disconnect_button_Click(object sender, EventArgs e)
        {
            try
            {
                Receiver.Abort();
                Send(Protocol.Tasks.Disconnect);

                stream.Close();
                tcpClient.Close();
                connection = false;

                disconnect_button.Visible = false;
                connect_button.Visible = true;

                clients_listBox.Items.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }

        }
        public void Connect()
        {
            byte[] msg_size_bytes = new byte[Protocol.size_size];
            stream.Read(msg_size_bytes, 0, Protocol.size_size);

            int msg_size = BitConverter.ToInt32(msg_size_bytes, 0);
            byte[] msg_bytes = new byte[msg_size];
            stream.Read(msg_bytes, 0, msg_size);

            string message = Encoding.Unicode.GetString(msg_bytes, 0, msg_size);

            if (message.StartsWith("Error: Duplicate name"))
            {
                MessageBox.Show(message, "Ошибка", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                Disconnect();
                return;
            }

            // Остальной код обработки подключения
            clients_listBox.Items.Clear();
            string[] data = message.Split('!');
            for (int i = 0; i < data.Length; i++)
            {
                string[] clientName = { data[i] };
                clients_listBox.Items.AddRange(clientName);
            }
        }
        public void Disconnect()
        {
            byte[] msg_size_bytes = new byte[Protocol.size_size];
            stream.Read(msg_size_bytes, 0, Protocol.size_size);

            int msg_size = BitConverter.ToInt32(msg_size_bytes, 0);
            byte[] msg_bytes = new byte[msg_size];
            stream.Read(msg_bytes, 0, msg_size);

            string message = Encoding.Unicode.GetString(msg_bytes, 0, msg_size);
            clients_listBox.Items.Remove(message);
        }

        public void Message()
        {
            byte[] msg_size_bytes = new byte[Protocol.size_size];
            stream.Read(msg_size_bytes, 0, Protocol.size_size);

            int msg_size = BitConverter.ToInt32(msg_size_bytes, 0);
            byte[] msg_bytes = new byte[msg_size];
            stream.Read(msg_bytes, 0, msg_size);

            string message = Encoding.Unicode.GetString(msg_bytes, 0, msg_size);

            // Отображаем сообщение в chat_richTextBox
            chat_richTextBox.AppendText(message);
        }

        private void send_button_Click(object sender, EventArgs e)
        {
            if (message_richTextBox.TextLength > 1)
            {
                // Проверяем, является ли сообщение личным сообщением
                if (message_richTextBox.Text.StartsWith("/private"))
                {
                    Send(Protocol.Tasks.Message, message_richTextBox.Text);
                }
                else
                {
                    // Рассылаем обычные сообщения всем клиентам
                    Send(Protocol.Tasks.Message, message_richTextBox.Text);
                }
                message_richTextBox.Clear();
            }
        }
        void Login_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                if (message_richTextBox.TextLength > 1)
                    Send(Protocol.Tasks.Message, message_richTextBox.Text);
                message_richTextBox.Clear();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
